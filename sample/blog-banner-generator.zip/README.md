# Blog Banner Generator

Generate high-quality, minimalist blog banner images from Markdown content using Gemini AI.

## Project Structure

- `src/App.tsx`: Main application component.
- `src/index.tsx`: Entry point.
- `src/components/`: Reusable UI components.
- `src/services/`: Business logic and API services (e.g., `geminiService.ts`).
- `src/types.ts`: TypeScript type definitions.
- `index.html`: Main HTML file.
- `metadata.json`: App metadata.
- `package.json`: Dependencies and scripts.
- `tsconfig.json`: TypeScript configuration.
- `vite.config.ts`: Vite configuration.

## Features

- **AI Analysis**: Analyzes blog title, intro, and description to derive a visual concept.
- **Minimalist Design**: Generates banners with intentional negative space for text overlay.
- **SEO/AEO Optimized**: Automatically generates optimized `alt` and `title` tags.
- **Professional Style**: Uses a refined vector-like style with a professional color palette.
