import { GoogleGenAI, Type } from "@google/genai";
import { BannerAnalysis, GeminiServiceConfig } from '../types';

export class GeminiService {
  private ai: any; // Using any because the types might be tricky with this specific SDK version

  constructor(config: GeminiServiceConfig) {
    this.ai = new GoogleGenAI({ apiKey: config.apiKey });
  }

  async analyzeMarkdown(markdown: string): Promise<BannerAnalysis> {
    const prompt = `[Role]
당신은 블로그 컨텐츠를 분석하여 전문적이고 미니멀한 '비즈니스 컨셉 일러스트' 배너를 설계하는 시각 디자이너입니다.

[Input Analysis]
입력된 마크다운 데이터('${markdown}')에서 핵심 키워드를 추출하여, 이를 추상적인 비즈니스 오브제로 치환하여 구상하세요.

[Design Principles]
다음은 첫 번째 참조 이미지의 화풍을 재현하기 위한 필수 디자인 규칙입니다.

1. Visual Style (Detailed Description):
   - **Shading:** 복잡한 채색 대신, 연한 그레이 톤의 부드러운 평면 음영(Flat Shading)만 사용하여 입체감을 줍니다.
   - **Elements:** 인물이나 사물 주변에 추상적인 비즈니스 요소들이 정교하게 레이어드된 스타일입니다. 
   - **Mood:** 전문적(Professional)이고 지적인 분위기를 유지하며, 캐릭터가 포함될 경우 감정이 절제된 차분한 표정을 유지합니다.

2. Strict Color Palette:
   - **Background:** 완전한 화이트(#FFFFFF) 또는 아주 연한 그레이(#F9F9F9).
   - **Main Objects:** 딥 네이비(Deep Navy), 스틸 그레이(Steel Gray).
   - **Constraint:** 주황, 노랑 등 원색이나 화려한 유채색은 절대 사용하지 마세요. 오직 무채색과 네이비의 조합으로만 구성합니다.

[Output Format]
반드시 아래의 JSON 형식으로만 응답하세요.

{
  "brief_concept": "전문적인 스타일과 네이비 톤을 활용하여 [핵심 키워드]를 형상화한 컨셉입니다.",
  "image_alt": "SEO/AEO에 최적화된 이미지 설명. 포스트의 핵심 키워드를 포함하여 검색 엔진이 주제를 명확히 이해할 수 있도록 작성 (예: 'LLM 기술의 핵심 구조를 시각화한 전문적인 비즈니스 일러스트')",
  "image_title": "검색 결과 가시성을 높이는 간결하고 매력적인 이미지 제목"
}`;

    const result = await this.ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            prompt: { type: Type.STRING, description: "English image generation prompt" },
            concept: { type: Type.STRING, description: "One sentence explanation in Korean" },
            image_alt: { type: Type.STRING, description: "SEO and AEO optimized alt text for the image, including core keywords" },
            image_title: { type: Type.STRING, description: "Short, catchy title for the image optimized for search visibility" }
          },
          required: ["prompt", "concept", "image_alt", "image_title"]
        }
      }
    });

    return JSON.parse(result.text || "{}");
  }

  async generateImage(visualPrompt: string): Promise<string> {
    const result = await this.ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: [{
        role: 'user',
        parts: [{
          text: visualPrompt + " Minimalist, clean, professional photography, high resolution, no text, 16:9 aspect ratio.",
        }]
      }],
      config: {
        imageConfig: {
          aspectRatio: "16:9",
        }
      }
    });

    let imageUrl = null;
    for (const part of result.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        break;
      }
    }

    if (!imageUrl) {
      throw new Error("Failed to generate image data.");
    }

    return imageUrl;
  }
}
