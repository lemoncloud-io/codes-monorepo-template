
import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="p-4 text-center">
      <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500 py-2">
        AI Toy-ify
      </h1>
    </header>
  );
};
