
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { ImageDisplay } from './components/ImageDisplay';
import { Loader } from './components/Loader';
import { SparklesIcon } from './components/icons/SparklesIcon';
import { transformToToyImage } from './services/geminiService';

const App: React.FC = () => {
  const [originalFile, setOriginalFile] = useState<File | null>(null);
  const [originalImagePreview, setOriginalImagePreview] = useState<string | null>(null);
  const [toyImage, setToyImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = (file: File) => {
    setOriginalFile(file);
    setToyImage(null);
    setError(null);
    const reader = new FileReader();
    reader.onloadend = () => {
      setOriginalImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleTransformClick = useCallback(async () => {
    if (!originalFile) return;

    setIsLoading(true);
    setToyImage(null);
    setError(null);

    try {
      const generatedImage = await transformToToyImage(originalFile);
      setToyImage(generatedImage);
    } catch (err) {
      console.error(err);
      setError('이미지 변환에 실패했습니다. 다시 시도해주세요.');
    } finally {
      setIsLoading(false);
    }
  }, [originalFile]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100 text-slate-800">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto bg-white/70 backdrop-blur-xl rounded-2xl shadow-lg p-6 md:p-10 border border-slate-200">
          
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-700">당신의 사진을 장난감으로!</h2>
            <p className="text-slate-500 mt-2">사진을 업로드하면 AI가 귀여운 장난감 이미지로 만들어 드려요.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="flex flex-col items-center">
              <h3 className="text-lg font-bold mb-3 text-slate-600">원본 사진</h3>
              <ImageUploader onImageSelect={handleImageUpload} currentImage={originalImagePreview} />
            </div>
            <div className="flex flex-col items-center">
               <h3 className="text-lg font-bold mb-3 text-slate-600">토이 이미지</h3>
              <ImageDisplay imageUrl={toyImage} isLoading={isLoading} error={error} />
            </div>
          </div>
          
          <div className="mt-10 text-center">
            <button
              onClick={handleTransformClick}
              disabled={!originalFile || isLoading}
              className="inline-flex items-center justify-center px-8 py-4 bg-purple-600 text-white font-bold rounded-full shadow-lg hover:bg-purple-700 disabled:bg-slate-400 disabled:cursor-not-allowed transform hover:scale-105 transition-all duration-300 ease-in-out focus:outline-none focus:ring-4 focus:ring-purple-300"
            >
              {isLoading ? (
                <>
                  <Loader small={true} />
                  <span className="ml-2">변환 중...</span>
                </>
              ) : (
                <>
                  <SparklesIcon className="w-6 h-6 mr-2" />
                  <span>장난감으로 변신!</span>
                </>
              )}
            </button>
          </div>

        </div>
      </main>
      <footer className="text-center py-6 text-slate-500 text-sm">
        <p>Powered by Gemini API</p>
      </footer>
    </div>
  );
};

export default App;
