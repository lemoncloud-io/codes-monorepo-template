
import React from 'react';
import type { GeneratedContent } from '../types';
import { ResultItem } from './ResultItem';

interface ResultsDisplayProps {
  content: GeneratedContent;
}

const TitleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.7-3.7a1 1 0 0 0-1.4-1.4l-1.6 1.6a1 1 0 0 0 0 1.4l-1.6 1.6Z"/>
    <path d="M21 16V8a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-1"/>
    <path d="M7 16h6"/>
    <path d="M7 12h8"/>
    <path d="M7 8h8"/>
  </svg>
);

const TagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M12 2H2v10l9.29 9.29a1 1 0 0 0 1.42 0l8.58-8.58a1 1 0 0 0 0-1.42L12 2z"/>
    <path d="M7 7h.01"/>
  </svg>
);

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ content }) => {
  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2 text-cyan-300">
          <TitleIcon />
          추천 블로그 제목
        </h2>
        <div className="space-y-3">
          {content.titles.map((title, index) => (
            <ResultItem key={`title-${index}`} text={title} />
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2 text-blue-300">
          <TagIcon />
          추천 태그
        </h2>
        <div className="flex flex-wrap gap-3">
          {content.tags.map((tag, index) => (
            <ResultItem key={`tag-${index}`} text={tag} isTag={true} />
          ))}
        </div>
      </div>
    </div>
  );
};

// Add fade-in animation to tailwind config (or in a style tag for simplicity here)
const style = document.createElement('style');
style.innerHTML = `
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
.animate-fade-in {
  animation: fadeIn 0.5s ease-out forwards;
}
`;
document.head.appendChild(style);
