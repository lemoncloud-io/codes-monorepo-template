
import { GoogleGenAI, Modality } from "@google/genai";
import type { ImageDetails } from '../utils/imageUtils';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    // In a real app, you might show a UI message instead of throwing an error.
    // For this context, we assume the key is provided.
    console.warn("API_KEY environment variable not set. App will not function correctly.");
}

const getAI = () => {
    if (!process.env.API_KEY) {
        throw new Error("API_KEY is not configured.");
    }
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

const generationModel = 'gemini-2.5-flash-image';

export const generateFigure = async (imageDetails: ImageDetails): Promise<string> => {
    try {
        const ai = getAI();
        const response = await ai.models.generateContent({
            model: generationModel,
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: imageDetails.base64,
                            mimeType: imageDetails.mimeType,
                        },
                    },
                    {
                        text: '사진 속 인물을 귀여운 3D 스타일의 토이 피규어로 만들어줘. 배경은 단순한 단색의 밝은 회색으로 해줘.',
                    },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
        
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
                return part.inlineData.data;
            }
        }
        throw new Error("생성된 이미지 데이터가 없습니다.");

    } catch (error) {
        console.error("피규어 생성 중 오류 발생:", error);
        throw new Error("피규어 생성에 실패했습니다. API 키를 확인하거나 다시 시도해주세요.");
    }
};

export const changeHairColor = async (imageDetails: ImageDetails, color: string): Promise<string> => {
    try {
        const ai = getAI();
        const response = await ai.models.generateContent({
            model: generationModel,
            contents: {
                parts: [
                    {
                        inlineData: {
                            data: imageDetails.base64,
                            mimeType: imageDetails.mimeType,
                        },
                    },
                    {
                        text: `피규어의 머리색을 ${color}색으로 바꿔줘. 머리 이외의 다른 부분은 절대 바꾸지 마. 배경도 그대로 유지해줘.`,
                    },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });

        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
                return part.inlineData.data;
            }
        }
        throw new Error("색상이 변경된 이미지 데이터가 없습니다.");

    } catch (error) {
        console.error("머리색 변경 중 오류 발생:", error);
        throw new Error("머리색 변경에 실패했습니다. 다시 시도해주세요.");
    }
};
