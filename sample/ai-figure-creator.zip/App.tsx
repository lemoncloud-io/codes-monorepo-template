
import React, { useState, useRef } from 'react';
import Header from './components/Header';
import Spinner from './components/Spinner';
import { fileToImageDetails } from './utils/imageUtils';
import type { ImageDetails } from './utils/imageUtils';
import { generateFigure, changeHairColor } from './services/geminiService';
import { HAIR_COLORS } from './constants';

const App: React.FC = () => {
    const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [loadingMessage, setLoadingMessage] = useState<string>('');
    const [error, setError] = useState<string | null>(null);

    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        setError(null);
        setGeneratedImage(null);
        
        // Create a displayable URL for the original image
        const objectUrl = URL.createObjectURL(file);
        setOriginalImageUrl(objectUrl);

        try {
            setIsLoading(true);
            setLoadingMessage('피규어를 생성하는 중...');
            const imageDetails = await fileToImageDetails(file);
            const newFigureBase64 = await generateFigure(imageDetails);
            setGeneratedImage(newFigureBase64);
        } catch (err) {
            setError(err instanceof Error ? err.message : '알 수 없는 오류가 발생했습니다.');
        } finally {
            setIsLoading(false);
            setLoadingMessage('');
        }
    };

    const handleColorChange = async (colorName: string, colorValue: string) => {
        if (!generatedImage) return;

        setError(null);
        try {
            setIsLoading(true);
            setLoadingMessage(`${colorName} 색으로 변경하는 중...`);
            // The generated image is a base64 string, and we'll assume PNG for edits.
            const currentImageDetails: ImageDetails = {
                base64: generatedImage,
                mimeType: 'image/png'
            };
            const updatedFigureBase64 = await changeHairColor(currentImageDetails, colorValue);
            setGeneratedImage(updatedFigureBase64);
        } catch (err) {
            setError(err instanceof Error ? err.message : '알 수 없는 오류가 발생했습니다.');
        } finally {
            setIsLoading(false);
            setLoadingMessage('');
        }
    };

    const triggerFileInput = () => {
        fileInputRef.current?.click();
    };

    const UploadPlaceholder = () => (
        <div className="flex flex-col items-center justify-center h-full border-2 border-dashed border-gray-600 rounded-2xl p-8 text-center bg-gray-800/50">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <p className="text-gray-400">여기에 원본 사진이 표시됩니다.</p>
        </div>
    );

    const FigurePlaceholder = () => (
        <div className="flex flex-col items-center justify-center h-full border-2 border-dashed border-gray-600 rounded-2xl p-8 text-center bg-gray-800/50">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M12 6V4m0 16v-2M8 8l1.414-1.414M14.586 14.586L16 16m-1.414-8.414L16 6m-8.414 9.414L6 16" />
                <path d="M12 14a2 2 0 100-4 2 2 0 000 4z" />
             </svg>
            <p className="text-gray-400">AI가 생성한 피규어가 여기에 나타납니다.</p>
        </div>
    );

    return (
        <div className="bg-gray-900 text-white min-h-screen font-sans">
            <Header />
            <main className="container mx-auto p-4 md:p-8">
                {error && (
                    <div className="bg-red-900/50 border border-red-500 text-red-300 px-4 py-3 rounded-lg relative mb-6" role="alert">
                        <strong className="font-bold">오류: </strong>
                        <span className="block sm:inline">{error}</span>
                    </div>
                )}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                    {/* Left Panel */}
                    <div className="flex flex-col gap-4">
                        <h2 className="text-2xl font-bold text-cyan-400">1. 사진 업로드</h2>
                        <input type="file" ref={fileInputRef} onChange={handleFileChange} accept="image/*" className="hidden" />
                        <button onClick={triggerFileInput} disabled={isLoading} className="w-full bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 ease-in-out flex items-center justify-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                            </svg>
                            <span>사진 선택하기</span>
                        </button>
                        <div className="aspect-square w-full rounded-2xl overflow-hidden bg-gray-800 shadow-lg">
                            {originalImageUrl ? (
                                <img src={originalImageUrl} alt="Original upload" className="w-full h-full object-cover" />
                            ) : (
                                <UploadPlaceholder />
                            )}
                        </div>
                    </div>

                    {/* Right Panel */}
                    <div className="flex flex-col gap-4">
                        <h2 className="text-2xl font-bold text-fuchsia-400">2. 피규어 꾸미기</h2>
                        <div className="aspect-square w-full rounded-2xl overflow-hidden bg-gray-800 shadow-lg relative">
                            {isLoading && (
                                <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center z-10">
                                    <Spinner />
                                    <p className="mt-4 text-lg">{loadingMessage}</p>
                                </div>
                            )}
                            {generatedImage ? (
                                <img src={`data:image/png;base64,${generatedImage}`} alt="Generated figure" className="w-full h-full object-cover" />
                            ) : (
                                !isLoading && <FigurePlaceholder />
                            )}
                        </div>
                        {generatedImage && !isLoading && (
                            <div className="bg-gray-800 p-4 rounded-2xl">
                                <h3 className="text-lg font-semibold mb-3 text-center">머리색 변경</h3>
                                <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-7 gap-3">
                                    {HAIR_COLORS.map(color => (
                                        <button 
                                            key={color.value} 
                                            onClick={() => handleColorChange(color.name, color.value)}
                                            disabled={isLoading}
                                            className="p-2 rounded-lg flex flex-col items-center gap-2 transition-transform duration-200 hover:scale-110 focus:outline-none focus:ring-2 focus:ring-fuchsia-400 disabled:opacity-50 disabled:cursor-not-allowed"
                                        >
                                            <div className={`w-10 h-10 rounded-full ${color.colorClass} border-2 border-gray-600`}></div>
                                            <span className="text-xs font-medium">{color.name}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default App;
