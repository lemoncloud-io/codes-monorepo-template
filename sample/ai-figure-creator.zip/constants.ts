
export interface HairColor {
    name: string;
    value: string;
    colorClass: string;
}

export const HAIR_COLORS: HairColor[] = [
    { name: '금발', value: 'blonde', colorClass: 'bg-yellow-300' },
    { name: '갈색', value: 'brown', colorClass: 'bg-amber-700' },
    { name: '검정', value: 'black', colorClass: 'bg-black' },
    { name: '빨강', value: 'red', colorClass: 'bg-red-500' },
    { name: '파랑', value: 'blue', colorClass: 'bg-blue-500' },
    { name: '핑크', value: 'pink', colorClass: 'bg-pink-400' },
    { name: '초록', value: 'green', colorClass: 'bg-green-500' },
];
