
import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="bg-gray-800/30 backdrop-blur-sm p-4 shadow-lg sticky top-0 z-20">
            <div className="container mx-auto flex items-center justify-center">
                <h1 className="text-3xl font-extrabold tracking-tight">
                    <span className="bg-gradient-to-r from-cyan-400 to-fuchsia-500 bg-clip-text text-transparent">
                        AI 피규어 생성기
                    </span>
                </h1>
            </div>
        </header>
    );
};

export default Header;
