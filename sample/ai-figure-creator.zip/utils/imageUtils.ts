
export interface ImageDetails {
    base64: string;
    mimeType: string;
}

export const fileToImageDetails = (file: File): Promise<ImageDetails> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const result = reader.result as string;
            // The result is 'data:image/jpeg;base64,LzlqLz...', we only need the part after the comma.
            const base64 = result.split(',')[1];
            const mimeType = file.type;
            if (!base64 || !mimeType) {
                reject(new Error("Failed to read file details"));
                return;
            }
            resolve({ base64, mimeType });
        };
        reader.onerror = (error) => reject(error);
    });
};
